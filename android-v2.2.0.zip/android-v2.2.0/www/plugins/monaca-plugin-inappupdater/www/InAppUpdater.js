cordova.define("monaca-plugin-inappupdater.monaca.InAppUpdater", function(require, exports, module) {
var mBaseUpdater  = function(){
};

var pluginName = "MonacaInAppUpdaterPlugin";

var Q = {
    defer: function() { return monaca.Q.defer(); } ,
    resolve: function() { return monaca.Q.resolve(); },
    reject: function(args) { return monaca.Q.reject(args); }
};

function jsonError( error ) {
  if (typeof error == "string") {
    return { code : 0 , message : error };
  }
  return error;
}

mBaseUpdater.prototype.getServerVersion = function(args) {
  var d = Q.defer();
  cordova.exec(
    function(json) { d.resolve(json); } ,
    function(error) { d.reject( jsonError(error) ); },
    pluginName,
    "getServerVersionAction",
    [args]
  );
  return d.promise;
};

mBaseUpdater.prototype.forceStopGetServerVersion = function() {
  var d = Q.defer();
  cordova.exec(
    function(json) { d.resolve(json); } ,
    function(error) { d.reject( jsonError(error) ); },
    pluginName,
    "forceStopGetServerVersionAction",
    []
  );
  return d.promise;
};

mBaseUpdater.prototype.getLocalVersion = function() {
  var d = Q.defer();
  cordova.exec(
    function(json) { d.resolve(json); },
    function(error) { d.reject( jsonError(error) ); },
    pluginName,
    "getLocalVersionAction",
    []
  );
  return d.promise;
};

mBaseUpdater.prototype.download = function(args) {
  var d = Q.defer();
  if (args.updateNumber == null || args.updateNumber <= 0) {
    d.reject( jsonError("argments error " + JSON.stringify(args) ) );
  }
  cordova.exec(
    function(json) {
      if (json.type == "progress") {
        d.notify( json );
      } else {
        d.resolve(json);
      }
    },
    function(error) { d.reject( jsonError(error) ); },
    pluginName,
    "downloadAction",
    [ args ]
  );
  return d.promise;
};

mBaseUpdater.prototype.forceStopDownload = function() {
  var d = Q.defer();
  cordova.exec(
    function(json) { d.resolve(json); } ,
    function(error) { d.reject( jsonError(error) ); },
    pluginName,
    "forceStopDownloadAction",
    []
  );
  return d.promise;
};

mBaseUpdater.prototype.updateAndRestart = function() {
  var d = Q.defer();
  cordova.exec(
    function(json) {
      if (json && json.type == "progress") {
        d.notify( json );
      } else {
        d.resolve(json);
      }
    },
    function(error) {
      d.reject( jsonError(error) );
    },
    pluginName,
    "updateAndRestartAction",
    [ ]
  );
  return d.promise;
};

mBaseUpdater.prototype.status = function() {
  var d = Q.defer();
  cordova.exec(
    function(json) {
      d.resolve(json);
    },
    function(error) {
      d.reject( jsonError(error) );
    },
    pluginName,
    "statusAction",
    [ ]
  );
  return d.promise;
};

mBaseUpdater.prototype.showAlertDialog = function(args) {
  var d = Q.defer();
  cordova.exec(
    function(json) {
      if (json.type == 1) {
        d.resolve(json);
      } else {
        if (json.type == 2) {
          var handler = args.dismiss;
          if (handler != null) {
            handler();
          }
        } else if (json.type == 3 && args.button != null) {
          var handler = args.button.handler;
          if (handler != null) {
            handler();
          }
        } else if (json.type == 4 && args.cancel != null) {
          var handler = args.cancel.handler;
          if (handler != null) {
            handler();
          }
        }
      }
    },
    function(error) {
      d.reject( jsonError(error) );
    },
    pluginName,
    "showAlertDialogAction",
    [ args ]
  );
  return d.promise;

};

mBaseUpdater.prototype.dismissAlertDialog = function() {
  var d = Q.defer();
  cordova.exec(
    function(json) {
      d.resolve(json);
    },
    function(error) {
      d.reject( jsonError(error) );
    },
    pluginName,
    "dismissAlertDialogAction",
    [ ]
  );
  return d.promise;

};

mBaseUpdater.prototype.showProgressDialog = function(args) {
  var d = Q.defer();
  cordova.exec(
    function(json) {
      if (json.type == 1) {
        d.resolve(json);
      } else {
         if (json.type == 2) {
           var handler = args.dismiss;
           if (handler != null) {
             handler();
           }
         } else if (json.type == 3 && args.cancel != null) {
          var handler = args.cancel.handler;
          if (handler != null) {
            handler();
          }
        }
      }
    },
    function(error) {
      d.reject( jsonError(error) );
    },
    pluginName,
    "showProgressDialogAction",
    [ args ]
  );
  return d.promise;

};

mBaseUpdater.prototype.changeProgressDialog = function(args) {
  var d = Q.defer();
  cordova.exec(
    function(json) {
      d.resolve(json);
    },
    function(error) {
      d.reject( jsonError(error) );
    },
    pluginName,
    "changeProgressDialogAction",
    [ args ]
  );
  return d.promise;

};



mBaseUpdater.prototype.dismissProgressDialog = function() {
  var d = Q.defer();
  cordova.exec(
    function(json) {
      d.resolve(json);
    },
    function(error) {
      d.reject( jsonError(error) );
    },
    pluginName,
    "dismissProgressDialogAction",
    [ ]
  );
  return d.promise;

};

mBaseUpdater.prototype.networkStatus = function() {
  var d = Q.defer();
  cordova.exec(
    function(json) {
      d.resolve(json);
    },
    function(error) {
      d.reject( jsonError(error) );
    },
    pluginName,
    "networkStatusAction",
    [ ]
  );
  return d.promise;
};

mBaseUpdater.prototype.terminateApp = function() {
  cordova.exec(
    null,
    null,
    pluginName,
    "terminateAppAction",
    [ ]
  );
};


mBaseUpdater.prototype.autoUpdate = function( options ) {
  var self = this;
  var connectDelay = options.connectDelay || 0;
  // var initOptions = {};
  // initOptions.connectionTimeout = options.connectTimeout;
  // initOptions.androidUseExternalStorage = options.androidUseExternalStorage;
  // initOptions.additionalHeaders = options.additionalHeaders;
  var dialogMessages = {};
  dialogMessages.confirm3G = { title : 'Alert' , message: 'You are now on the cellular network. Do you want to proceed?' };
  dialogMessages.prepare = { title : 'Prepare' , message : 'Preparing' };
  dialogMessages.download = { title : 'Download' , message : 'Downloading' };
  if (options.dialogMessages) {
    dialogMessages.confirm3G = options.dialogMessages.confirm3G || dialogMessages.confirm3G;
    dialogMessages.prepare   = options.dialogMessages.prepare   || dialogMessages.prepare;
    dialogMessages.download  = options.dialogMessages.download  || dialogMessages.download;
  }
  var nextTask = options.nextTask || function() { };
  var failTask = options.failTask || function() { };
  var flag3G = false;
  var targetVersion = null;
  var targetUpdateNumber = "";
  var url = null;
  var flagNeedDownload = true;
  var flagForceStopDownload = false;
  // log("auto update");

  var progressDialogParameters = {
    title : dialogMessages.prepare.title ,
    message : dialogMessages.prepare.message ,
    max : 0 ,
    progress : 0 ,
    cancel : {
      label : "Cancel" ,
      handler : function() {
        flagForceStopDownload = true;
        self.forceStopGetServerVersion().then( function() { } , function() {  } ).done();
        self.forceStopDownload().then( function() { } , function() {  } ).done();
      }
    }
  };

  self.showProgressDialog(progressDialogParameters).then( function() {
    var d = Q.defer();
    setTimeout( function() {
      d.resolve();
    } , connectDelay );
    return d.promise;
  }).then( function() {
    return self.networkStatus();
  }).then( function(res) {
    if (flagForceStopDownload) {
      return Q.reject( { code : 1003 , message : "User Cancel" } );
    }
    if (res.network) {
      if (res.wifi == false && res.mobile == true) {
        flag3G = true;
      }
      return self.getServerVersion();
    } else {
      return Q.reject( { code : -1 } );
    }
  }).then( function(res) {
    if (res.updatable) {
      targetVersion = res.myVersion;
      targetUpdateNumber = res.latestUpdateNumber;
      url = res.updateInfo.url;
      if (targetVersion == res.downloadedVersion && targetUpdateNumber == res.downloadedUpdateNumber) {
        flagNeedDownload = false;
      }
      if (flagNeedDownload && flag3G) {

        var d = Q.defer();
        self.dismissProgressDialog().then( function() {
            self.showAlertDialog( {
              title : dialogMessages.confirm3G.title ,
              message : dialogMessages.confirm3G.message ,
              button : { label : "OK" , handler : function() {
                self.showProgressDialog(progressDialogParameters).then( function() {
                  d.resolve();
                } );
              } } ,
              cancel : { label : "Cancel" , handler : function() {
                self.showProgressDialog(progressDialogParameters).then( function() {
                  d.reject( { code: 2001 , message : "User Cancel" } );
                } );
              } }
            } ).then(
              function(json) {
              },
              function(fail) {
                self.showProgressDialog(progressDialogParameters).then( function() {
                  d.reject(fail);
                });
              }
            );
          }
        )
        return d.promise;

      } else {
        return Q.resolve();
      }
    } else {
      return Q.reject( { code : -1 } );
    }
  }).then( function() {
    if (flagForceStopDownload) {
      return Q.reject( { code : 1003 , message : "User Cancel" } );
    }
    if (! flagNeedDownload) {
      return Q.resolve();
    }
    return self.download( { version : targetVersion , updateNumber : targetUpdateNumber , url : url } ).progress(
      function (res) {
        self.changeProgressDialog({
          title : dialogMessages.download.title ,
          message : dialogMessages.download.message ,
          max : res.total ,
          progress : res.count
        }).done();
      }
    );
  } ).then( function(res) {
    return self.dismissProgressDialog();
  } ).then( function() {
    nextTask({ requireRestart: true});
  } ).fail( function(res) {
    self.dismissProgressDialog().fin( function() {
      if (res.code == -1) { // NO ERROR
        nextTask({ requireRestart: false });
      } else { // ERROR
        failTask( { error : res } );
      }
    } );
  } );
};


var baseUpdater = new mBaseUpdater();
module.exports = baseUpdater;

});
