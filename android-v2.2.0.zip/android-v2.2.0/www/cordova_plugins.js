cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
  {
    "id": "monaca-plugin-monaca-core.monaca",
    "file": "plugins/monaca-plugin-monaca-core/www/monaca.js",
    "pluginId": "monaca-plugin-monaca-core"
  },
  {
    "id": "cordova-plugin-splashscreen.SplashScreen",
    "file": "plugins/cordova-plugin-splashscreen/www/splashscreen.js",
    "pluginId": "cordova-plugin-splashscreen",
    "clobbers": [
      "navigator.splashscreen"
    ]
  },
  {
    "id": "monaca-plugin-common.monaca.Q",
    "file": "plugins/monaca-plugin-common/www/Q.js",
    "pluginId": "monaca-plugin-common",
    "clobbers": [
      "monaca.Q"
    ]
  },
  {
    "id": "monaca-plugin-inappupdater.monaca.InAppUpdater",
    "file": "plugins/monaca-plugin-inappupdater/www/InAppUpdater.js",
    "pluginId": "monaca-plugin-inappupdater",
    "clobbers": [
      "monaca.InAppUpdater"
    ]
  }
];
module.exports.metadata = 
// TOP OF METADATA
{
  "cordova-custom-config": "5.0.2",
  "monaca-plugin-monaca-core": "3.2.0",
  "cordova-plugin-whitelist": "1.3.3",
  "cordova-plugin-splashscreen": "5.0.1",
  "monaca-plugin-common": "3.0.0",
  "monaca-plugin-lib-encrypt-and-inappupdater": "1.1.0",
  "monaca-plugin-inappupdater": "4.1.0"
};
// BOTTOM OF METADATA
});